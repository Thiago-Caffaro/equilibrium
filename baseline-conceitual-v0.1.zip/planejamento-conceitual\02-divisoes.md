# Divisões

> Parte da **Baseline Conceitual v0.1**.

## 1. Função das divisões

As divisões são a estrutura de especialização do modpack. No primeiro ingresso na campanha, o jogador será apresentado a uma escolha inicial em uma interface inspirada conceitualmente na experiência de seleção do Origins.

O termo “clã” apareceu na ideia inicial, mas “divisão” tornou-se o termo de trabalho mais frequente. Nenhum dos dois nomes é definitivo.

### Decisões fechadas

- Cada jogador pertence a **uma divisão por vez**.
- Mais de um jogador pode escolher a mesma divisão.
- Ter mais integrantes em uma divisão não deve tornar sua progressão mais difícil; a colaboração interna tende a torná-la mais fácil.
- A escolha não pode ser trocada livremente apenas para acessar uma receita conveniente.
- Foi aceita a proposta de uma respecialização excepcional com reinício ou perda da maestria anterior. A maestria anterior não permanece disponível para uso. Processo, custo, espera, tratamento da insígnia e consequências para o mundo continuam em aberto.
- Por enquanto, a divisão controla **progressão e crafting**.
- Bônus, passivas e modificadores de combate no estilo de uma classe de RPG não fazem parte do escopo estabelecido. A expressão “até então” preserva a possibilidade de reavaliar isso futuramente.
- A divisão passa a contar para o estado do mundo quando é escolhida; não é exigido um marco inicial adicional para que seja reconhecida.

## 2. As quatro divisões

O planejamento começou com três divisões — Tecnologia, Magia e Aventura — e foi expandido por decisão do usuário para incluir uma quarta: Comerciantes.

### 2.1 Tecnologia

**Identidade conceitual:** automação, indústria, logística, energia, engenharia, processamento e armazenamento tecnológico.

Seu papel não é receber acesso irrestrito a toda forma de geração. Tecnologia transforma recursos e trabalho previamente conquistados em escala. Ela deve ser poderosa, mas depender de componentes, materiais e marcos das outras divisões em avanços importantes.

Possíveis áreas internas:

- automação mecânica inicial;
- indústria e processamento avançado;
- redes de armazenamento e autocrafting;
- geração e distribuição de energia;
- química, reatores e produção em massa;
- logística e transporte.

Nenhuma subdivisão ou lista de mods está fechada.

### 2.2 Magia

**Identidade conceitual:** feitiços, rituais, invocações, manipulação sobrenatural, transmutação, utilidade, combate mágico e automação de natureza arcana.

Magia não deve existir apenas como um conjunto de armas ou efeitos pessoais. Ela precisa participar da economia do pack e produzir componentes, processos e capacidades desejados por Tecnologia, Aventura e Comerciantes.

Possíveis áreas internas:

- magia programável ou de propósito geral;
- rituais e invocações;
- armazenamento ou transporte mágico;
- feitiços de combate e utilidade;
- transmutação e processamento arcano;
- automação mágica.

Os sistemas e mods concretos continuam em avaliação.

### 2.3 Aventura

**Identidade conceitual vigente:** exploração, estruturas, dimensões, bosses, artefatos, combate, troféus, materiais exclusivos e domínio de ameaças.

Aventura não pode ser a divisão de quem “escolheu não mexer em mods”. Ela precisa de progressão própria e de coisas que as outras divisões não possam produzir simplesmente em uma máquina.

Funções discutidas como candidatas:

- obter ou processar materiais exclusivos de exploração;
- controlar chaves, portais ou formas de invocar bosses;
- avançar por dimensões e estruturas;
- aprimorar artefatos e equipamentos de origem aventureira;
- fornecer troféus e conquistas usados como provas de maestria;
- enfrentar ameaças que, sem aventureiros, eventualmente alcançam os assentamentos.

**Ponto não fechado:** ainda não foi decidido se a progressão de Aventura será principalmente baseada em conquistas — bosses, locais e troféus — ou se terá uma carga de crafting comparável às demais divisões.

### 2.4 Comerciantes

“Comerciantes” é um nome provisório para a quarta divisão, criada para representar um estilo de gameplay mais tranquilo sem torná-lo secundário.

**Identidade conceitual:** prosperidade, produção renovável, agricultura, pesca, criação de animais, culinária, construção de cidades, comunidades, comércio, decoração e outros sistemas de desenvolvimento social ou econômico.

Uma atividade tranquila não é automaticamente adequada à divisão. Os mods incluídos devem possuir algum tipo de progressão real e fornecer resultados que o restante do grupo deseje.

Possíveis responsabilidades:

- alimentos e cadeias culinárias avançadas;
- cultivos e produtos especializados;
- pesca e criação;
- desenvolvimento de vilas ou cidades;
- comércio, rotas, mercados ou reputação;
- materiais artesanais e decorativos de alto valor;
- manutenção da prosperidade do mundo.

**Pontos não fechados:** nome definitivo, identidade visual, fronteira entre agricultura e automação tecnológica, progressão concreta e natureza exata da economia controlada pela divisão.

## 3. Independência inicial e dependência posterior

O primeiro nível de maestria é independente. Seu objetivo é permitir que o jogador conheça sua escolha e comece a desenvolver sua própria linguagem de gameplay.

Conforme o nível aumenta, a interdependência cresce. Nos patamares finais, avançar deve ser igualmente difícil para as divisões e pode se tornar impossível sem ajuda de jogadores de outros caminhos.

```text
MAESTRIA INICIAL
aprendizado da própria divisão

MAESTRIA INTERMEDIÁRIA
primeiras trocas e componentes cruzados

MAESTRIA AVANÇADA
dependências fortes entre especialistas

FIM DA PROGRESSÃO
domínio coletivo do conjunto do pack
```

O número de níveis não está definido. I, II, III e IV foram usados somente como exemplos.

## 4. Distribuição livre, consequências reais

O pack não exige que cada divisão tenha o mesmo número de jogadores. Uma distribuição teórica de 25% por divisão é a mais simétrica, mas não é condição de validade da campanha.

Grupos podem escolher:

- uma representação próxima entre os quatro pilares;
- várias pessoas na mesma divisão;
- uma ou mais divisões ausentes;
- uma campanha inteira concentrada em uma única divisão.

Essas composições permanecem jogáveis, mas influenciam o Equilíbrio do Mundo. A liberdade de composição não significa ausência de consequência.

## 5. Especialização interna

Vários jogadores na mesma divisão não precisam repetir exatamente as mesmas atividades. A conversa reconheceu a possibilidade de, por exemplo, dois tecnológicos se concentrarem em automação mecânica e armazenamento, ou dois magos avançarem por sistemas arcanos diferentes.

Essa subdivisão é orgânica e depende da modlist. Não foram criadas subclasses formais.

O sistema de coesão compara a maestria dos integrantes da divisão, não exige que todos executem os mesmos mods ou tarefas.

## 6. Respecialização

Foi aceita conceitualmente uma troca excepcional de divisão acompanhada de reinício ou perda da maestria anterior. A maestria abandonada deixa de ser utilizável; arquivamento ou preservação parcial para uso futuro não são possibilidades vigentes. Isso protege a especialização contra trocas oportunistas.

Ainda é necessário decidir:

- quando a troca pode ocorrer;
- qual processo, custo ou autorização ela exige;
- como o reinício ou a perda da maestria anterior é efetivado;
- como a insígnia anterior é tratada;
- como a troca afeta o roster e as rupturas do mundo;
- se existe período de espera.

Nenhuma dessas regras deve ser presumida.

## 7. Nomes e lore

Tecnologia, Magia, Aventura e Comerciantes são nomes funcionais. Conceitos como Engenho, Arcano, Descoberta e Prosperidade apareceram apenas como possibilidades de lore e não foram aprovados como nomes oficiais.

A história que justificará os quatro pilares, as insígnias e o Equilíbrio ainda não foi criada. Os sistemas foram desenhados para permitir uma explicação diegética posterior, sem fixá-la antecipadamente.
