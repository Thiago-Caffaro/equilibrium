# Registro de decisões, revisões e exceções

> Parte da **Baseline Conceitual v0.1**. Formulações antigas são preservadas mesmo quando foram substituídas.

Este registro documenta como o estado atual foi alcançado. Ele existe para impedir que uma formulação antiga seja recuperada sem perceber que foi revisada mais tarde.

## 1. Linha cronológica resumida

### Fase A — diagnóstico do pack anterior

1. O problema foi definido como a escalada desproporcional de automação e tecnologia em um grupo de aproximadamente seis jogadores.
2. O servidor local foi declarado capaz de lidar com packs de qualquer calibre, mas eficiência e worldgen continuaram sendo prioridades.
3. O usuário confirmou disposição para alterar valores, configurações e receitas e para criar integrações customizadas.
4. Surgiu a diretriz de tornar as especializações igualmente importantes, não igualmente rápidas.

### Fase B — automação e referências

5. Foi formulada a ideia de que automação deveria vir depois do domínio do conteúdo.
6. E9E foi inicialmente recomendado como base direta, com 1.19.2 como forte possibilidade.
7. Depois, com a criação das insígnias e divisões, o usuário perguntou se E9E poderia ser usado apenas como fonte de análise.
8. A posição mudou: E9E deixou de ser base e passou a ser referência, junto com E6E, packs modernos e o pack anterior.
9. O usuário confirmou explicitamente essa direção e pediu que as referências sejam mencionadas no GitHub.

### Fase C — divisões, insígnias e maestria

10. O usuário propôs escolha inicial estilo Origins, divisões/clãs e uma insígnia catalisadora de craftings.
11. A insígnia foi definida como vinculada, protegida contra perda e não consumida ao atuar como catalisadora permanente. Ela é emprestável dentro da mesma divisão com desgaste, sem consumo da propriedade ou da maestria nativa.
12. A evolução ocorreria em um bloco próprio por meio de itens dos mods centrais.
13. Três divisões foram inicialmente sugeridas: Magia, Tecnologia e Aventura.
14. O usuário adicionou a quarta divisão, Comerciantes, para agricultura, pesca, cidades, comércio, decoração e gameplay tranquilo com progressão.
15. Foi confirmado que o jogador pertence a uma divisão por vez, com respecialização excepcional e reinício do progresso.
16. Foi confirmado que a divisão controla, por enquanto, progressão e crafting.
17. Foi confirmado que o número máximo de níveis depende da modlist e que o primeiro nível é independente, sem dependência das demais divisões nessa etapa.
18. Foi estabelecido que patamares altos exigem ajuda de outras divisões.

### Fase D — Equilíbrio do Mundo

19. Para evitar hard-lock quando uma divisão está ausente, o usuário propôs uma barra persistente de Equilíbrio e a cadeia ruptura/eventos → fragmentos → shards raros, consumidos ao substituir a autoridade da insígnia em craftings.
20. O sistema passou a usar um roster persistente baseado em últimos logins, e não apenas jogadores online.
21. O mundo reconhece uma divisão quando ela é escolhida.
22. Ausências acumulam deterioração com o tempo e várias rupturas podem coexistir.
23. O usuário definiu percentuais reais de composição, como 75% Magia e 25% Tecnologia.
24. Foi adicionada a coesão interna: equipes do mesmo nível são estáveis independentemente de estarem no I ou IV.
25. Desigualdade interna alta pode gerar pontos negativos.
26. Distribuição populacional desigual também pesa, mesmo quando todas as divisões existem.
27. Diferença entre divisões pesa de forma moderada, menor que a fragmentação interna.
28. O caos passou a ser uma estratégia legítima de risco e oportunidade. A cadeia confirmada de rupturas, eventos, fragmentos e shards está ligada à ausência de divisões; não foi decidido se baixa coesão ou disparidade também cria ruptura equivalente.
29. Equilíbrio e World Progress foram separados.
30. World Progress foi escolhido como representação das quatro divisões, visualizado com quatro cores/identidades e baseado no progresso médio de cada uma, não no jogador mais avançado. Fórmula, layout, percentual agregado e tratamento visual de divisões ausentes ficaram abertos.

## 2. Decisões substituídas

### RD-001 — E9E como base

**Formulação antiga:** usar Enigmatica 9: Expert como base estrutural ou fork, com preferência aproximada por 1.19.2.

**Estado atual:** substituída.

**Formulação vigente:** construir identidade, scripts, receitas e core próprios; usar E9E, E6E e outros packs como referências de seleção, integração e pacing.

### RD-002 — Três divisões

**Formulação antiga:** Magia, Tecnologia e Aventura seriam suficientes para cerca de seis jogadores.

**Estado atual:** substituída.

**Formulação vigente:** quatro divisões, incluindo Comerciantes.

### RD-003 — Equilíbrio baseado sobretudo em presença

**Formulação antiga:** se ao menos um representante de cada divisão existisse, o mundo poderia ser considerado equilibrado; proporção não deveria importar.

**Estado atual:** substituída.

**Formulação vigente:** presença continua importante, mas distribuição populacional real participa do cálculo. 25/25/25/25 é o ideal teórico, não uma exigência.

### RD-004 — Um representante equivalente a três

**Formulação antiga:** a quantidade de especialistas traria benefícios orgânicos, mas não deveria mudar o Equilíbrio.

**Estado atual:** substituída.

**Formulação vigente:** quantidade por equipe, total de ativos e distribuição entram no cálculo, sem tornar uma divisão maior automaticamente melhor.

### RD-005 — Uma única barra de estado

**Formulação antiga:** uma barra geral de Equilíbrio poderia resumir presença e ausência.

**Estado atual:** expandida.

**Formulação vigente:** existem dois eixos conceitualmente independentes — Equilíbrio e World Progress. A forma final da HUD continua aberta.

### RD-006 — Mundo medido pelo jogador mais avançado

**Formulação antiga:** usar o maior tier foi apresentado como uma possibilidade para escalar shards.

**Estado atual:** rejeitada em favor da opção C.

**Formulação vigente:** World Progress representa as quatro divisões, usa quatro cores/identidades e o progresso médio de cada uma. Fórmula, layout, percentual agregado e tratamento visual de divisões ausentes permanecem abertos.

### RD-007 — Insígnia em muitas receitas

**Formulação antiga:** grande parte das receitas de uma divisão exigiria literalmente a insígnia.

**Revisão proposta:** concentrar a autoridade em poucos componentes-chave ou pontos de controle.

**Estado atual:** parcialmente aberto. A função catalisadora está confirmada; a granularidade não foi decidida porque o item 14 ficou sem resposta.

### RD-008 — Durabilidade e quebra

**Formulação antiga:** o empréstimo causaria durabilidade e a insígnia acabaria quebrando, embora fosse descrita também como indestrutível.

**Revisão proposta:** usar integridade/estabilidade, chegar a um estado fraturado e nunca destruir a propriedade.

**Estado atual:** conflito ainda não resolvido em detalhe. É fechado que a progressão e a propriedade não são destruídas; o comportamento físico em zero e a restauração estão abertos.

## 3. Decisões fechadas com exceções

### EX-001 — Uma divisão por jogador

Regra geral: uma divisão por vez.

Exceção aceita: respecialização excepcional com reinício ou perda da maestria. A maestria abandonada não permanece utilizável. Processo, custo, espera, tratamento da insígnia e consequências para o mundo continuam em aberto.

### EX-002 — Insígnia intransferível

Regra geral: propriedade e progresso nativo nunca são consumidos pelo uso catalisador da insígnia.

Exceção: autoridade pode ser emprestada temporariamente a outro jogador elegível, com desgaste quando ultrapassa a maestria nativa. Esse desgaste não transfere propriedade nem consome a maestria; o comportamento final em zero continua aberto.

### EX-003 — Divisão ausente

Regra geral: níveis altos dependem de outras divisões.

Exceção sistêmica: se uma divisão necessária não existir na campanha, a ruptura dessa ausência pode produzir eventos e fragmentos que levam a shards. O shard substitui de forma consumível a autoridade da insígnia em um crafting. A rota evita hard-lock, mas não equivale a um especialista permanente. Outros usos do shard permanecem abertos.

### EX-004 — Distribuição ideal

Referência matemática: 25% por divisão é a composição mais simétrica.

Exceção de design: distribuições diferentes permanecem jogáveis e podem ser apenas moderadamente instáveis.

### EX-005 — Cooperação

Direção principal: cooperação e coesão estabilizam o mundo.

Exceção deliberada: jogadores podem manter divisões ausentes e explorar as rupturas correspondentes. Baixa coesão e disparidade reduzem o Equilíbrio, mas ainda não está decidido se produzem, sozinhas, ruptura equivalente.

### EX-006 — Automação

Direção vigente: automação deve ser conquistada depois do domínio.

Exceção pretendida: no endgame, grande escala pode ser válida. O teto exato ainda não foi confirmado.

## 4. Propostas recorrentes que não são decisões

As ideias abaixo apareceram com frequência ou em resumos, mas não devem ser tratadas como fechadas:

- quatro atos formais chamados Establishment, Expansion, Mastery e Endgame;
- exatamente quatro níveis de maestria;
- pontos de controle como única forma de gating;
- Insignia Workbench obrigatória;
- estabilidade proporcional à diferença de tiers;
- insígnia “fraturada” em zero;
- proprietário continuar usando uma insígnia fraturada;
- restauração temática diferente por divisão;
- shards impossíveis de automatizar;
- custo crescente para compensações repetidas;
- eventos específicos como autômatos, corrupção arcana ou pragas;
- E9E, E6E, E10, FTB Evolution ou ATM10 definirem a versão;
- presença garantida de qualquer mod candidato citado;
- 1 sistema de terreno e no máximo 1 grande sistema de biomas como limite rígido;
- questline extensa;
- endgame com Avaritia, Draconic Evolution ou sistemas equivalentes;
- linguagem específica de lore como Arcano, Engenho, Descoberta e Prosperidade.

## 5. Decisões numéricas deliberadamente adiadas

Os pontos abaixo não representam falhas da ideia. Foram conscientemente deixados para uma fase posterior de modlist, protótipo e balanceamento:

- quantidade máxima de maestrias;
- custo e itens de ascensão;
- desgaste por empréstimo;
- pesos do Equilíbrio;
- thresholds de contribuição negativa;
- atividade e inatividade;
- deterioração e recuperação;
- frequência e dificuldade de eventos;
- raridade e custo dos shards;
- pacing;
- escala de energia e produção;
- quantidade de estruturas e dimensões;
- tamanho e desempenho esperados do pack.

## 6. Regras para futuras atualizações destes documentos

Quando uma pendência for decidida:

1. atualizar o documento temático;
2. remover ou marcar o item correspondente em `09-decisoes-em-aberto.md`;
3. registrar a decisão aqui com data ou versão do planejamento;
4. se substituir uma ideia anterior, preservar as duas formulações e marcar claramente qual está vigente;
5. não transformar exemplos de mods, receitas ou números em compromissos sem confirmação.
