# Decisões em aberto

> Parte da **Baseline Conceitual v0.1**. Este arquivo permanece aberto por definição e não representa decisões já tomadas.

Este arquivo é a lista canônica do que **não deve ser presumido**. Uma proposta ter aparecido em exemplos ou resumos não a transforma em decisão.

Decisões numéricas são mantidas aqui mesmo quando o conceito correspondente já está fechado, porque fórmulas e valores podem alterar profundamente a experiência.

## 1. Identidade, nome e lore

- **AB-001 — Nome do modpack:** nenhum nome foi aprovado. “Desempregados: Rebalanced” apareceu apenas como brincadeira/provisório.
- **AB-002 — Lore central:** ainda será criada.
- **AB-003 — Nomes finais das divisões:** Tecnologia, Magia, Aventura e Comerciantes são nomes de trabalho.
- **AB-004 — Vocabulário oficial:** clã, divisão, pilar, força, insígnia, shard e ruptura ainda podem receber nomenclatura diegética.
- **AB-005 — Relação entre lore e mecânicas:** falta decidir como o mundo explica insígnias, Equilíbrio, rupturas e World Progress.

## 2. Plataforma e distribuição

- **AB-010 — Versão do Minecraft.**
- **AB-011 — Loader.**
- **AB-012 — Intenção de publicação pública ou uso privado.**
- **AB-013 — Política de licença e incorporação de materiais de referência.**
- **AB-014 — Forma exata de reconhecer referências no GitHub.**

## 3. Divisões

- **AB-020 — Identidade final de cada divisão:** fronteiras, nomes, cores e símbolos.
- **AB-021 — Respecialização:** processo, custo, condições, espera, tratamento da insígnia e consequências para o mundo. A maestria anterior é reiniciada/perdida e não permanece utilizável.
- **AB-022 — Passivas e habilidades:** o escopo vigente é progressão/crafting; falta decidir se isso poderá mudar no futuro.
- **AB-023 — Aventura:** progressão principalmente por conquistas ou por crafting comparável às outras divisões.
- **AB-024 — Comerciantes:** economia, progressão, responsabilidades e fronteira com automação tecnológica.
- **AB-025 — Subespecializações internas:** se serão apenas orgânicas ou algum dia formais.
- **AB-026 — Tratamento de contas alternativas:** a divisão conta ao ser escolhida, mas o risco de representação artificial não foi resolvido.

## 4. Maestria e ascensão

- **AB-030 — Quantidade máxima de níveis:** I–IV foi apenas exemplo.
- **AB-031 — Critérios de cada nível:** dependem da modlist.
- **AB-032 — Bloco de evolução:** aparência, nome e funcionamento da estante/altar.
- **AB-033 — Provas de domínio:** itens, conquistas, XP e demais requisitos.
- **AB-034 — Contribuições cruzadas:** em quais níveis começam e com que intensidade.
- **AB-035 — Progressão individual versus cerimônia coletiva:** a maestria é individual, mas falta definir como outras pessoas participam da ascensão.
- **AB-036 — Repetição por jogadores da mesma divisão:** se a segunda pessoa refaz integralmente provas já dominadas pelo servidor.

## 5. Insígnias

- **AB-040 — Escopo dos crafts:** muitas receitas diretas ou poucos pontos de controle estratégicos.
- **AB-041 — Bancada própria:** existência, papel e relação com o bloco de ascensão.
- **AB-042 — Nome do desgaste:** durabilidade, estabilidade, integridade, ressonância ou outro conceito.
- **AB-043 — Fórmula de desgaste de empréstimo.**
- **AB-044 — Empréstimo entre jogadores do mesmo nível:** sem desgaste, desgaste mínimo ou regra comum.
- **AB-045 — Estado em zero:** fraturada, inativa ou outro comportamento.
- **AB-046 — Autoridade do proprietário em zero:** continua usando a própria maestria ou fica limitado.
- **AB-047 — Restauração:** processo, custo e materiais.
- **AB-048 — Restauração por divisão:** sistema universal ou quatro formas temáticas.
- **AB-049 — Insígnia durante respecialização.**
- **AB-050 — Casos extremos:** containers, perda fora do inventário, cópias simultâneas e devolução ao dono precisam de especificação futura.

## 6. Progressão e automação

- **AB-060 — Confirmação formal de Automation Follows Mastery:** é a diretriz vigente, mas o item de confirmação não foi respondido.
- **AB-061 — Recursos nunca automatizáveis.**
- **AB-062 — Momento de quarries, farms virtuais e geração cultivável.**
- **AB-063 — Estrutura definitiva dos gates.**
- **AB-064 — Teto de poder do endgame.**
- **AB-065 — Presença de sistemas extremos:** Draconic Evolution, Avaritia, Allthemodium e equivalentes foram exemplos, não escolhas.
- **AB-066 — Estrutura em atos:** existência oficial, quantidade e nomes.
- **AB-067 — Visibilidade dos atos:** ferramenta interna ou fases perceptíveis.
- **AB-068 — Pacing e duração da campanha.**
- **AB-069 — Papel exato de bosses como gates.**
- **AB-070 — Catch-up permanente:** além do empréstimo de insígnias.

## 7. Equilíbrio e roster

- **AB-080 — Intervalo de verificação dos últimos logins.**
- **AB-081 — Tempo até um jogador ser classificado como inativo.**
- **AB-082 — Administração manual do roster.**
- **AB-083 — Peso da distribuição populacional.**
- **AB-084 — Peso da coesão interna.**
- **AB-085 — Peso da diferença entre divisões.**
- **AB-086 — Fórmula de pontos negativos.**
- **AB-087 — Efeito da quantidade de integrantes sobre a contribuição.**
- **AB-088 — Faixas e nomes de estabilidade.**
- **AB-089 — Velocidade da deterioração por ausência.**
- **AB-090 — Recuperação:** instantânea ou gradual, e sua velocidade.
- **AB-091 — Persistência histórica além das rupturas atuais.**
- **AB-092 — Outras origens de ruptura:** se baixa coesão ou grande disparidade, sem ausência, também pode criar uma ruptura equivalente e seus eventos. Até essa decisão, esses fatores apenas reduzem o Equilíbrio e podem gerar contribuição negativa.

## 8. Rupturas, eventos e shards

- **AB-100 — Nome e identidade de cada ruptura.**
- **AB-101 — Eventos concretos de Magia ausente.**
- **AB-102 — Eventos concretos de Aventura ausente.**
- **AB-103 — Eventos concretos de Tecnologia ausente.**
- **AB-104 — Eventos concretos de Comerciantes ausentes.**
- **AB-105 — Conteúdo reutilizado de mods e conteúdo original.**
- **AB-106 — Bosses, inimigos e modificadores usados.**
- **AB-107 — Thresholds e frequência dos eventos.**
- **AB-108 — Escalonamento com ruptura e World Progress.**
- **AB-109 — Chance e quantidade de fragmentos.**
- **AB-110 — Quantidade de fragmentos por shard.**
- **AB-111 — Regra anti-automação:** spawners, farms virtuais, loot automático e participação do jogador.
- **AB-112 — Custo crescente por compensações repetidas:** proposta não confirmada.
- **AB-113 — Autoridade fora de crafting:** o uso consumível como substituto da insígnia em crafting está confirmado; falta decidir se o shard poderá autorizar outras ações.
- **AB-114 — Níveis e nomenclatura dos shards.**

## 9. World Progress e interface

- **AB-120 — Fórmula do progresso médio de cada divisão:** a média por divisão está escolhida conceitualmente; o cálculo não está.
- **AB-121 — Tratamento visual de uma divisão ausente:** as quatro divisões devem ser representadas, mas a aparência da parcela ausente não foi definida.
- **AB-122 — Percentual agregado:** se haverá e como será calculado um valor geral além das quatro representações.
- **AB-123 — Relação matemática entre World Progress e categoria de shard.**
- **AB-124 — Layout, quantidade de barras e formato final da HUD.**
- **AB-125 — Posição permanente na tela e possibilidade de ocultar.**
- **AB-126 — Cores, símbolos, tooltips e explicações.**
- **AB-127 — Como comunicar fragmentação sem culpar jogadores.**

## 10. Modlist e referências

- **AB-130 — Modlist final.**
- **AB-131 — Quantidade de mods principais.**
- **AB-132 — Lista final de referências.**
- **AB-133 — Matriz de papéis, tiers e sobreposição.**
- **AB-134 — Decisão individual sobre cada candidato discutido.**
- **AB-135 — Mods que fornecerão conteúdo para eventos de ruptura.**
- **AB-136 — Política para mods redundantes que possuem um sistema único útil.**
- **AB-137 — Quais receitas/configurações externas serão somente estudadas e quais ideias serão adaptadas.**

## 11. Worldgen e eficiência

- **AB-140 — Sistema principal de terreno.**
- **AB-141 — Mod de biomas e quantidade.**
- **AB-142 — Estruturas selecionadas.**
- **AB-143 — Dimensões selecionadas.**
- **AB-144 — Densidade e distribuição.**
- **AB-145 — Orçamento de desempenho.**
- **AB-146 — Métricas e benchmarks multiplayer.**
- **AB-147 — Política de chunks carregados.**
- **AB-148 — Pré-geração e tamanho da região.**

## 12. Experiência multiplayer

- **AB-150 — Questline:** extensa, leve ou descoberta orgânica.
- **AB-151 — Guias próprios de cada divisão.**
- **AB-152 — Regra para um jogador que deliberadamente impõe caos aos demais.**
- **AB-153 — Conflitos quando o único especialista fica ausente sem sair do roster.**
- **AB-154 — Proteções sociais contra exclusão de novatos.**
- **AB-155 — Política administrativa para corrigir escolhas e dados.**
- **AB-156 — Escala além de aproximadamente seis jogadores.**

## 13. Questões da lista original 10–24 que continuam sem resposta formal

A conversa respondeu os itens 1–9 e aprofundou o item 9. Os itens seguintes não receberam resposta direta:

10. pacote completo de regras da insígnia e empréstimo;
11. desgaste quando o receptor já possui o mesmo nível;
12. comportamento da insígnia esgotada e do proprietário;
13. restauração temática por divisão;
14. uso de pontos de controle em vez de inserir insígnia em muitas receitas;
15. confirmação de Automation Follows Mastery;
16. aceitação formal de poder extremo no endgame;
17. identidade detalhada de Aventura;
18. progressão de Aventura por crafting ou conquistas;
19. detalhes da ascensão individual e das contribuições externas;
20. catch-up permanente além do empréstimo;
21. atos perceptíveis ou apenas internos;
22. profundidade da questline;
23. formulação quantitativa da filosofia minimalista de worldgen;
24. confirmação literal da frase “o jogador não deve ser obrigado a dominar todos os mods; o grupo deve dominar o modpack coletivamente”.

Algumas partes desses itens já possuem fundamento em afirmações anteriores do usuário, registradas nos documentos temáticos. O que não foi explicitamente resolvido permanece aberto e não foi preenchido por inferência.
