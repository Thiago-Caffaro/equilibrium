# Insígnias e maestria

> Parte da **Baseline Conceitual v0.1**.

## 1. Papel do sistema

As insígnias são a representação física da especialização e uma das duas grandes mecânicas próprias do projeto, ao lado do Equilíbrio do Mundo.

Ao escolher uma divisão, o jogador recebe uma insígnia correspondente. Ela funciona como catalisadora de progressão e crafting e evolui conforme a maestria individual aumenta.

O conceito separa duas coisas:

```text
MAESTRIA
conhecimento e progresso conquistados pelo jogador

INSÍGNIA
representação física e catalisadora dessa autoridade
```

A conversa confirmou que a maestria pertence ao jogador. A insígnia não é a fonte descartável do progresso; ela o representa e permite exercê-lo em pontos importantes do pack.

A insígnia permanente e a maestria vinculada a ela não são consumidas quando a insígnia atua como catalisadora. Isso é diferente do desgaste aplicado durante empréstimos e dos shards, que são substitutos consumíveis para craftings quando a divisão necessária está ausente.

## 2. Regras de propriedade

### Decisões fechadas

- A insígnia fica vinculada ao jogador que a recebeu originalmente.
- A propriedade não pode ser transferida de forma permanente.
- A insígnia é indestrutível como progresso: morte, perda ou duplicação não devem apagar a maestria conquistada.
- O jogador deve permanecer protegido contra a perda da insígnia ao morrer.
- Se a insígnia estiver no chão, jogadores sem divisão ou de outra divisão não conseguem pegá-la.
- Jogadores da mesma divisão podem pegá-la, permitindo o empréstimo pretendido.
- Duas insígnias legítimas da mesma divisão e nível podem existir se pertencerem a jogadores diferentes.
- Uma duplicata da mesma insígnia vinculada deve ser eliminada, preservando uma única instância válida.
- Se a insígnia original for perdida, o sistema deve ser capaz de devolvê-la ou reemiti-la ao proprietário sem criar uma segunda progressão.

O método de validação e recuperação pertence ao futuro planejamento técnico e não é definido aqui.

## 3. Maestria individual

Cada jogador possui um nível próprio dentro de sua divisão.

```text
Ana — Magia III
Bruno — Magia I
Carlos — Tecnologia II
```

Jogadores da mesma divisão podem estar em níveis diferentes. Essa diferença é relevante tanto para o empréstimo quanto para a coesão da divisão no Equilíbrio do Mundo.

### Decisões fechadas

- O primeiro nível é independente.
- O nível máximo não é fixo e só deve ser definido depois que a modlist revelar quantas etapas reais fazem sentido.
- Níveis como I–IV foram exemplos, não uma decisão numérica.
- Em níveis mais altos, a progressão passa a depender fortemente de outras divisões.
- A evolução deve provar domínio dos sistemas importantes da própria divisão, e não ser apenas uma compra de XP.

## 4. Evolução da insígnia

A insígnia evoluirá por meio de um bloco próprio. A ideia inicial usou a imagem de um altar; a confirmação posterior descreveu uma espécie de **estante** ainda não planejada em detalhe.

Não existe decisão de que cada divisão terá necessariamente um bloco diferente. O que está estabelecido é a necessidade de um momento próprio de evolução da maestria.

Uma ascensão conceitual pode combinar:

- a insígnia atual;
- itens importantes dos mods centrais da própria divisão;
- provas de domínio ou conquistas;
- contribuições produzidas por outras divisões nos níveis em que a interdependência já deve existir.

Exemplo ilustrativo, não receita aprovada:

```text
Insígnia de Magia I
  + prova do sistema mágico A
  + prova do sistema mágico B
  + componente externo
  = Maestria de Magia II
```

Os mods, itens, quantidades, formato da prova e número de estágios permanecem em aberto.

## 5. A insígnia como catalisador

### O que está fechado

A insígnia permanente será usada diretamente como catalisadora em craftings e progressões importantes. Sua propriedade e a maestria do jogador não são consumidas ao cumprir esse papel. O empréstimo pode alterar o estado de desgaste da insígnia, mas não transfere nem consome sua propriedade ou o progresso nativo.

### O que evoluiu, mas não foi fechado

A ideia original previa inserir a insígnia em grande parte das receitas associadas a uma divisão. Depois surgiu a proposta de concentrar a autoridade em **pontos de controle**:

```text
Insígnia Tecnológica II
        ↓
componente-chave de Tecnologia II
        ↓
diversas máquinas e upgrades
```

Essa alternativa reduz repetição e mantém a insígnia nos momentos que realmente representam progressão. Ela foi apresentada como recomendação e usada em resumos posteriores, mas o item que pedia sua confirmação explícita não foi respondido.

Portanto, o estado correto é:

- a insígnia como catalisador de crafting/progressão está confirmada;
- a quantidade de receitas que a exigirá está em aberto;
- pontos de controle são a proposta vigente mais elaborada, não uma decisão fechada.

## 6. Empréstimo de autoridade

A propriedade da insígnia é intransferível, mas sua autoridade pode ser emprestada temporariamente.

O caso descrito foi um jogador de Magia III emprestando sua insígnia a outro jogador da mesma divisão que possui Magia I. O receptor consegue usar a autoridade superior para determinadas ações, mas cada uso provoca desgaste.

Esse mecanismo tem três objetivos:

- permitir ajuda emergencial;
- permitir que jogadores atrasados participem de conteúdo mais avançado;
- impedir que o empréstimo transforme permanentemente a maestria nativa do receptor.

```text
Maestria nativa I
  + insígnia emprestada III
  = autoridade temporária III

Maestria nativa continua I
```

### Decisões fechadas

- O empréstimo não transfere propriedade.
- O empréstimo não aumenta permanentemente a maestria do receptor.
- Usos acima da maestria real desgastam a insígnia emprestada.
- O desgaste acontece por uso/crafting, e não necessariamente de uma só vez.
- A insígnia precisa de alguma forma de reparo ou restauração futura.
- O desgaste não consome a maestria nativa nem transfere a propriedade da insígnia.

### Extensões propostas, ainda não confirmadas

Durante a conversa, foi sugerido substituir “durabilidade” por um conceito temático como estabilidade, integridade ou ressonância. Também foram propostas as seguintes regras:

- custo proporcional à diferença entre a maestria nativa e a autoridade concedida;
- custo diferente conforme a importância da ação;
- pouco ou nenhum desgaste ao emprestar para alguém do mesmo nível;
- estado “fraturado” em 0%, sem destruição do item;
- proprietário ainda capaz de exercer sua maestria nativa com a insígnia fraturada;
- restauração temática distinta para cada divisão.

Nenhuma dessas extensões recebeu confirmação formal. Elas devem permanecer como opções de design até serem decididas.

Em particular, esta baseline não decide o comportamento final ao chegar a zero desgaste. A permanência da propriedade e do progresso está fechada; o estado e a disponibilidade do item nesse ponto continuam em aberto.

## 7. Relação com catch-up

O empréstimo oferece uma forma elegante de ajuda a jogadores novos ou atrasados:

```text
grupo em nível avançado
        ↓
empresta autoridade temporária
        ↓
novato participa do conteúdo atual
        ↓
continua conquistando sua maestria real
```

Isso evita tanto entregar gratuitamente o progresso permanente quanto obrigar o novato a jogar isolado por semanas.

O item que perguntava se o empréstimo seria o único mecanismo de catch-up ou se também haveria redução permanente de requisitos não foi respondido. Logo, o empréstimo é um mecanismo previsto, mas a política completa de recuperação continua em aberto.

## 8. Relação com o Equilíbrio

As insígnias ajudam a reduzir disparidades dentro de uma divisão, porque jogadores avançados podem auxiliar os atrasados. Ao mesmo tempo, o empréstimo tem custo e não substitui o progresso real.

Se uma divisão inteira estiver ausente, insígnias emprestadas não resolvem o problema, pois não existe especialista daquela divisão para fornecer uma. Nesse caso, a ruptura causada por essa ausência pode gerar eventos e fragmentos que levam a shards temporários.

```text
especialista presente
→ insígnia permanente e reutilizável

especialista ausente
→ shard raro, consumível e substituto da autoridade da insígnia em crafting
```

O uso confirmado do shard é em craftings. Possíveis usos da autoridade temporária fora de crafting permanecem em aberto.

## 9. Pontos que não devem ser presumidos

- nome definitivo da insígnia e dos estados de desgaste;
- quantidade máxima de níveis;
- aparência e funcionamento detalhado da estante/altar;
- itens e provas de cada ascensão;
- frequência com que a insígnia aparece fisicamente em receitas;
- comportamento do empréstimo entre jogadores de mesmo nível;
- fórmula de desgaste;
- estado exato ao chegar a zero;
- permissões do proprietário durante uma fratura;
- método e custo de restauração;
- existência de restaurações diferentes por divisão;
- mecanismo adicional de catch-up permanente;
- tratamento detalhado da insígnia durante uma respecialização.
