# Filosofia de progressão e automação

> Parte da **Baseline Conceitual v0.1**.

## 1. Problema de progressão a evitar

No pack anterior, vários sistemas capazes de gerar recursos, mobs, energia, processamento e logística estavam disponíveis simultaneamente. Individualmente, cada mod poderia ser aceitável; combinados, criavam uma sequência semelhante a:

```text
automação inicial
→ quarry ou geração virtual
→ multiplicação de minério
→ farms de mobs
→ recursos cultiváveis
→ energia e logística sem atrito
→ quase toda escassez desaparece
```

Enquanto isso, exploração ainda dependia de deslocamento e bosses, e magia mantinha progressões próprias que já não eram necessárias para a economia do grupo.

O novo design precisa controlar **quando** uma limitação é removida e **quais especializações** participam dessa conquista.

## 2. Importância equivalente, velocidade diferente

A meta não é sincronizar artificialmente o ritmo de todas as divisões.

- Tecnologia pode escalar produção.
- Magia pode concentrar utilidade, transmutação, automação arcana e componentes únicos.
- Aventura pode avançar por risco, localização, bosses e materiais que não são fabricados.
- Comerciantes podem construir prosperidade, cadeias produtivas e valor econômico por um gameplay mais tranquilo.

O equilíbrio vem da importância recíproca, não de curvas idênticas.

## 3. Automation Follows Mastery

Durante a conversa, foi formulada a regra:

> A automação completa deve vir depois que o grupo demonstrou domínio convencional do conteúdo correspondente.

Essa diretriz apareceu repetidamente como parte central do design e foi incluída nos handoffs posteriores. No entanto, o item específico que pedia sua confirmação formal não foi respondido porque a conversa parou para aprofundar o Equilíbrio.

Portanto, seu estado documental é **diretriz vigente, aguardando confirmação formal**.

O princípio pretende substituir:

```text
encontrar um recurso uma vez
→ automatizá-lo imediatamente
→ ignorar todo conteúdo associado
```

por:

```text
descobrir
→ obter convencionalmente
→ vencer o desafio relacionado
→ demonstrar domínio
→ liberar automação
```

Automação não é removida; ela se torna recompensa por domínio.

## 4. Exemplos discutidos, não receitas fechadas

### Automação de bosses ou mobs

Foi usado o exemplo de derrotar o Wither e conquistar Nether Stars antes de liberar uma rota como geração virtual por Hostile Neural Networks.

### Mineração automatizada

Quarries ou sistemas equivalentes apareceriam depois de mineração, exploração, máquinas intermediárias e marcos de dimensões ou bosses, em vez de eliminar a mineração quase no início.

### Mystical Agriculture

Mystical Agriculture foi tratado como candidato possível, desde que completamente reposicionado. Seeds poderosas poderiam exigir uma combinação de conquistas de Aventura, componentes mágicos e catalisadores tecnológicos, além de aparecer somente depois de o recurso já ter sido dominado.

Também foi sugerido que alguns recursos especiais não possuam seeds.

Esses exemplos demonstram a filosofia. Nenhum confirma a presença dos mods, os itens citados, o tier ou a receita.

## 5. Interdependência crescente

### Decisão fechada — primeiro nível independente

O primeiro nível de maestria é independente. Ele permite que o jogador conheça e desenvolva a própria divisão sem depender das demais nessa etapa.

### Decisão fechada — avanços altos dependem dos outros

No fim da progressão, as divisões devem ser igualmente difíceis de avançar e podem ser impossíveis sem ajuda de jogadores que escolheram outras especializações.

Uma progressão tecnológica avançada pode precisar de um catalisador produzido por Magia, de um material conquistado por Aventura e de um produto raro dos Comerciantes. De forma recíproca, progressões mágicas, aventureiras e comerciais precisam de resultados das demais divisões.

O objetivo é criar frases sociais como:

> Precisamos falar com o nosso mago.

> O aventureiro ainda não trouxe esse material.

> A infraestrutura dos Comerciantes é necessária para essa etapa.

Não se deseja que cada jogador execute sozinho todos os mods que originam os componentes.

### Exceção sistêmica — divisão necessária ausente

A dependência entre divisões descreve a **rota normal** dos níveis altos. Se uma divisão necessária não tiver nenhum representante ativo, a campanha não entra em hard-lock.

```text
divisão necessária ausente
→ ruptura associada à ausência
→ eventos
→ fragmentos
→ shard consumível
→ substituição temporária da autoridade da insígnia em um crafting
```

Essa rota é excepcional, perigosa e custosa. Ela não cria um especialista, não concede maestria permanente e não transforma o shard em infraestrutura reutilizável. O uso confirmado é como substituto consumível da autoridade de crafting; outros usos possíveis do shard permanecem em aberto.

## 6. Gates e pontos de controle

A conversa distinguiu dificuldade de progressão de complexidade repetitiva de crafting.

Pontos de controle podem concentrar um avanço em poucos componentes significativos:

```text
prova de maestria
   + contribuições cruzadas
   + insígnia
   = componente-chave do novo patamar
```

Esse componente passa a liberar um conjunto de receitas sem inserir a insígnia fisicamente em todas elas.

Como o item de confirmação dessa abordagem não foi respondido, pontos de controle permanecem como proposta preferida, não decisão fechada. A necessidade de gating por progressão e crafting, por outro lado, foi confirmada.

## 7. Progressão pessoal e coletiva

Maestria é individual: jogadores da mesma divisão podem estar em níveis diferentes.

O avanço do pack é coletivo em outro sentido: o grupo produz as contribuições cruzadas e o World Progress representa as quatro divisões com quatro cores/identidades, usando o progresso médio de cada uma. Um único jogador não define sozinho o estágio da campanha. Fórmula, layout, percentual agregado e tratamento visual de divisões ausentes permanecem em aberto.

Esse desenho cria três escalas simultâneas:

```text
JOGADOR
maestria individual

DIVISÃO
coesão e capacidade coletiva

MUNDO
progresso médio e equilíbrio global
```

## 8. Estrutura em atos

Foi proposta uma estrutura interna de quatro atos:

1. **Establishment:** vanilla expandido, sistemas iniciais e automação limitada.
2. **Expansion:** especialização, primeiras integrações e acesso intermediário.
3. **Mastery:** automação pesada, produção em escala e poderes avançados.
4. **Endgame:** sistemas extremos e recompensas finais.

Também foram citados, apenas como ilustração, Create e Ars Nouveau no início; Mekanism, AE2, Occultism e dimensões na expansão; factories, autocrafting e algumas automações de recursos na maestria; Draconic Evolution, Mekanism endgame, Mystical Agriculture completo ou Avaritia no fim.

Nada dessa distribuição está fechado. O item que perguntava se os atos seriam perceptíveis pelos jogadores ou somente uma ferramenta interna também ficou sem resposta.

Assim, “quatro atos” é uma ferramenta de raciocínio proposta, não uma estrutura oficial.

## 9. Endgame

Foi defendida a possibilidade de permitir poder extremo somente depois que a progressão tenha cumprido sua função. A lógica é:

```text
produção absurda cedo
→ invalida o pack

produção absurda depois do domínio coletivo
→ pode ser recompensa
```

O item de confirmação formal do “endgame absurdo” não foi respondido. O teto de poder, a duração da campanha e a presença de mods de escalada extrema continuam em aberto.

## 10. Bosses, exploração e recursos

Uma diretriz discutida foi usar bosses como marcos de novos patamares em vez de apenas fontes de equipamento melhor. Materiais de exploração podem funcionar como provas não substituíveis por máquinas até que o conteúdo correspondente seja dominado.

Isso ajuda a manter Aventura relevante e impede que a economia tecnológica absorva todos os outros caminhos.

A lista de bosses, dimensões, drops exclusivos e automações posteriores não está definida.

## 11. Economia e escassez

O pack precisa preservar escassez até que o grupo tenha conquistado o direito de removê-la.

Para avaliar uma automação, o planejamento deverá perguntar:

- qual atividade ela substitui;
- qual divisão perde relevância quando ela aparece;
- qual conquista deveria vir antes;
- se outra automação já remove a mesma limitação;
- se o resultado continua exigindo contribuição de outros especialistas;
- se sua escala combina com o estágio atual do mundo.

## 12. Pontos em aberto

- confirmação formal de Automation Follows Mastery;
- teto de poder no endgame;
- existência oficial de atos e visibilidade deles;
- duração e pacing de cada fase;
- política de automação para cada categoria de recurso;
- recursos que nunca poderão ser automatizados;
- estrutura definitiva dos gates;
- quantidade e posição dos componentes cruzados;
- papel de bosses e dimensões em cada maestria;
- tratamento de farms virtuais, quarries e seeds;
- questline ou outro sistema de orientação;
- mecanismos permanentes de catch-up.
