# Experiência multiplayer

> Parte da **Baseline Conceitual v0.1**.

## 1. Público e cenário de uso

O projeto foi pensado a partir de um grupo de aproximadamente seis jogadores em um servidor local robusto. O tamanho exato do grupo pode variar, e o sistema precisa se adaptar à composição real da campanha.

O problema social original era a separação entre:

```text
poucos jogadores que dominam automação
→ controlam recursos e infraestrutura

demais jogadores
→ mantêm atividades mais lentas
→ deixam de ser necessários
```

O novo pack procura transformar especialização em colaboração e não em concentração permanente de poder.

## 2. Loop social desejado

```text
jogador escolhe uma divisão
→ desenvolve conhecimento próprio
→ produz resultados que os outros não substituem
→ recebe contribuições externas
→ sobe sua maestria
→ ajuda a divisão a permanecer coesa
→ contribui para o avanço do mundo
```

Uma interação saudável deve fazer o jogador procurar um especialista, negociar recursos, combinar uma expedição, organizar uma produção ou ajudar um colega atrasado.

## 3. Especialização sem isolamento

O jogador não deve precisar aprender todos os mods. Também não deve ficar confinado a uma ilha que não conversa com o restante da campanha.

O desenho busca uma rede recíproca:

```text
Tecnologia ↔ Magia
     ↕          ↕
Aventura  ↔ Comerciantes
```

Os vínculos exatos dependem da modlist. A regra de design é que nenhum caminho avançado seja completamente autossuficiente e que a dependência não flua em apenas uma direção.

## 4. Vários jogadores na mesma divisão

Mais de um jogador pode escolher o mesmo caminho. Isso não aumenta artificialmente a dificuldade da progressão. Ao contrário, permite:

- dividir sistemas internos;
- produzir componentes em paralelo;
- emprestar insígnias;
- ajudar colegas atrasados;
- explorar diferentes mods da mesma identidade;
- sustentar maior demanda das outras divisões.

O custo aparece no Equilíbrio caso esses jogadores avancem de forma muito desigual. A equipe precisa administrar não apenas seu topo de progresso, mas sua coesão.

## 5. Novos jogadores e catch-up

Quando um novo jogador entra em uma divisão já avançada, sua maestria inicial reduz a coesão do grupo:

```text
antes: IV, IV, IV
depois: IV, IV, IV, I
```

Essa consequência foi aceita como parte do sistema. Ela cria incentivo para que os veteranos ajudem o novato a se aproximar.

O empréstimo de insígnias permite participação temporária em conteúdo avançado sem converter I em IV permanentemente. Ele funciona como catch-up de autoridade, não como entrega de progresso.

Ainda não foi decidido se haverá também:

- redução permanente de requisitos antigos;
- bônus de recuperação baseado no World Progress;
- aceleração de etapas já dominadas pelo servidor;
- outro mecanismo de catch-up além do empréstimo.

## 6. Evitar culpabilização

O efeito de um novato ou jogador atrasado sobre o Equilíbrio pode gerar comportamento social indesejado se a interface o apontar como culpado.

Foi recomendado comunicar estados coletivos:

> O pilar Arcano está fragmentado.

em vez de:

> O jogador X está destruindo a estabilidade.

Essa escolha de linguagem não foi formalmente confirmada, mas é coerente com o objetivo de incentivar ajuda em vez de exclusão.

## 7. Presença persistente, não presença instantânea

O mundo usa um roster de jogadores ativos baseado em histórico de login. Sair para jantar, passar uma noite offline ou não estar conectado durante um evento não remove imediatamente a contribuição do jogador.

Isso evita que a estabilidade oscile a cada login e preserva a identidade da campanha.

Ao mesmo tempo, jogadores que abandonaram o servidor devem eventualmente deixar o roster. O tempo e o processo ainda serão definidos.

## 8. Campanhas de composição diferente

O mesmo pack deve suportar campanhas muito diferentes.

### Grupo distribuído

```text
2 Tecnologia
1 Magia
1 Aventura
2 Comerciantes
```

Tende a possuir acesso sustentável aos quatro pilares, embora distribuição e coesão ainda influenciem a estabilidade.

### Grupo concentrado

```text
6 Magia
```

Continua jogável, mas acumula rupturas de Tecnologia, Aventura e Comerciantes porque essas divisões estão ausentes. O grupo aceita eventos, perigo e uso recorrente de shards de crafting para compensar as ausências.

### Grupo representado, porém fragmentado

```text
Magia: IV, IV, I
Tecnologia: III
Aventura: III
Comerciantes: III
```

Todas as divisões existem, mas a coesão de Magia prejudica o mundo. A resposta social pretendida é ajudar o integrante atrasado.

## 9. Cooperação não obrigatoriamente pacífica

O design reconhece uma forma de jogo menos cooperativa. Um jogador pode avançar sozinho e reduzir a estabilidade. Se o grupo também mantiver divisões ausentes, poderá explorar os eventos das rupturas dessas ausências para obter fragmentos e shards.

O jogo não bloqueia essa escolha. A consequência vem do mundo:

- ameaças crescentes;
- rupturas simultâneas das divisões ausentes;
- obtenção difícil e demorada de compensações;
- manutenção constante do caos.

Essa rota pode criar tensão dentro da própria equipe e faz parte das possibilidades narrativas da campanha. Ainda não foi decidido se baixa coesão ou grande disparidade, sem ausência, também cria uma ruptura equivalente ou os mesmos eventos.

Não foram definidas regras de votação, consentimento do servidor ou proteção contra um jogador que imponha caos aos demais. Esse é um risco multiplayer ainda aberto.

## 10. Autoridade permanente e ajuda temporária

O sistema cria três formas de acesso:

| Forma | Natureza | Papel social |
|---|---|---|
| Maestria própria + insígnia | Permanente; propriedade e progresso não consumidos no uso catalisador | Especialista real e infraestrutura sustentável |
| Insígnia emprestada | Autoridade temporária com desgaste; propriedade e maestria nativa permanecem | Ajuda, emergência e catch-up |
| Shard de divisão ausente | Consumido ao substituir a autoridade da insígnia em crafting | Compensação sem especialista |

Essa distinção impede que ajuda elimine a importância da especialização.

## 11. Riscos sociais e de design identificados

### Monopólio de uma divisão

Um único especialista pode controlar um recurso essencial. O pack precisa incentivar troca sem tornar o grupo refém de disponibilidade pessoal. Shards resolvem ausência estrutural, mas não necessariamente conflitos internos.

### Contas alternativas

Como uma divisão passa a contar ao ser escolhida, contas alternativas podem registrar pilares sem participação real. O problema foi identificado, mas nenhuma contramedida foi decidida.

### Jogador inativo

O roster persistente precisa remover abandonos sem punir ausências comuns.

### Empréstimo abusivo

Se o desgaste for barato, uma insígnia avançada pode substituir permanentemente a progressão dos demais. Se for caro demais, o mecanismo deixa de ajudar. A fórmula é balanceamento futuro.

### Farming de rupturas

Se shards forem automatizáveis, a ausência de uma divisão pode virar uma fábrica superior à presença de um especialista. Salvaguardas foram propostas, mas ainda não confirmadas.

### Culpa sobre novatos

A coesão precisa incentivar assistência, não expulsão.

### Fragmentação de grupo

Quatro divisões em um grupo pequeno exigem que cada uma seja útil mesmo com um único integrante. A distribuição ideal não pode virar uma obrigação rígida.

## 12. Orientação ao jogador

Uma questline bem desenvolvida, guias por divisão e interfaces que mostrem dependências foram sugeridos como formas de reduzir confusão.

O item correspondente não foi respondido. Não está decidido se a experiência será fortemente guiada ou mais orgânica.

Independentemente do formato, a comunicação futura precisará explicar claramente:

- o que a escolha de divisão significa;
- como a maestria evolui;
- o que uma insígnia emprestada faz;
- por que o Equilíbrio mudou;
- diferença entre Equilíbrio e World Progress;
- consequências de divisões ausentes;
- natureza consumível dos shards.

## 13. Resultado multiplayer esperado

O resultado pretendido é uma campanha em que:

- ninguém precisa dominar todos os mods;
- ninguém se torna irrelevante apenas porque outro automatizou cedo;
- a equipe decide entre estabilidade e caos;
- novos jogadores podem ser ajudados sem receber progresso gratuito;
- composições diferentes geram campanhas diferentes;
- avançar sozinho é possível, mas afeta o mundo e o grupo;
- recursos e conquistas circulam entre especializações.

Os detalhes de interface, regras sociais e orientação permanecem parte do planejamento futuro.
